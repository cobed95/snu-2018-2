/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_03449675678378231231_0377897103_init();
    work_m_00306567565654716841_3547302247_init();
    work_m_15569575937267362711_3860540424_init();
    work_m_13027300350298100725_0879477022_init();
    work_m_17580770074232936230_3437662359_init();
    work_m_16541823861846354283_2073120511_init();


    xsi_register_tops("work_m_17580770074232936230_3437662359");
    xsi_register_tops("work_m_16541823861846354283_2073120511");


    return xsi_run_simulation(argc, argv);

}
