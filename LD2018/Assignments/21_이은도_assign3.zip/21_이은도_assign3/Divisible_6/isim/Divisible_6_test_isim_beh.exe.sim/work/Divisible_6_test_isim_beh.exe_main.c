/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_03449674271969612990_4291699262_init();
    work_m_03449674271969612990_2294878888_init();
    work_m_08901520261568803908_0053375879_init();
    work_m_14715160688679642159_4171490855_init();
    work_m_00782749056065016215_2016053589_init();
    work_m_16541823861846354283_2073120511_init();


    xsi_register_tops("work_m_00782749056065016215_2016053589");
    xsi_register_tops("work_m_16541823861846354283_2073120511");


    return xsi_run_simulation(argc, argv);

}
