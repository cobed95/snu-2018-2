#!/usr/bin/env bash

scala -J-Xmx128m -cp lib/proj-lib.jar:classes pp201802.projtest.Test
